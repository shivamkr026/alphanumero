════════════════════════════════════════════════════════════════
  NUMERO UNO MARKETING — HOSTINGER DEPLOYMENT PACKAGE
  Site: https://alphanumerouno.in
  Prepared: March 2026
════════════════════════════════════════════════════════════════

FILES TO UPLOAD (all go into public_html/)
─────────────────────────────────────────
  index.html        → Homepage (107KB)
  services.html     → Services & Pricing (41KB)
  clients.html      → Client Results (30KB)
  free-audit.html   → AI Audit Tool (206KB)
  .htaccess         → HTTPS + caching + security (REQUIRED)
  robots.txt        → Search crawler rules
  sitemap.xml       → SEO sitemap

BEFORE GOING LIVE — 5 THINGS TO COMPLETE
─────────────────────────────────────────
1. GSTIN: Search "Update in Admin" in index.html footer → replace with real GSTIN

2. UPI: Search "numerounomarketing@upi" in free-audit.html → confirm this is your real UPI ID

3. Razorpay: Set up link at rzp.io/l/numerounoaudit or replace with your actual Razorpay link
   in free-audit.html (search "rzp.io")

4. Anthropic API Key: The AI audit page needs your API key added to the browser
   (currently requires client-side key input on first use)

5. Meta Pixel: Add your Pixel ID to free-audit.html head — search "YOUR_PIXEL_ID"

DEPLOYMENT STEPS (Hostinger hPanel)
─────────────────────────────────────
1. Login to hPanel → File Manager → public_html/
2. Delete any existing index.html or index.php
3. Upload this ZIP → Extract directly into public_html/
4. Enable SSL: hPanel → SSL/TLS → Let's Encrypt → Install (free)
5. Test: https://alphanumerouno.in → should load with green padlock

AFTER DEPLOYMENT
─────────────────
1. Submit sitemap: Google Search Console → Sitemaps → add "sitemap.xml"
2. Activate GA4: uncomment the GA4 block in index.html (search "G-XXXXXXXXXX")
3. Verify Meta Pixel firing: install "Meta Pixel Helper" Chrome extension
4. Test WhatsApp alerts: run a test audit, confirm notification arrives at +91 96320 91371

PAGES
──────
  /           → index.html
  /services   → services.html  (Hostinger URL rewriting via .htaccess)
  /clients    → clients.html
  /free-audit → free-audit.html

CONTACT
────────
  Phone:  +91 96320 91371
  Email:  contact@alphanumerouno.digital
  Office: No.63, Katha No.6, Agara, Thataguni, Bangalore 560082
